- [[AssertJ rewrites]]
- [[RxJava to Reactor Migration]]
-
- Rewrites:
	- `ReactorCollectionWrapper`, `.flux(...).next`-> `.mono`. ([link](https://github.com/PicnicSupermarket/picnic-platform/pull/8660#discussion_r811889761))
	- `joining("")` to `joining()` ([link](https://github.com/PicnicSupermarket/picnic-store/pull/1208#discussion_r816056875))
	- `.filter(Optional::isPResent).map(get?)` to `Mono::justOrEmpty` [link](https://github.com/PicnicSupermarket/picnic-platform/pull/8660#discussion_r814011080)
	- `ImmutableMap.<String, Boolean>builder().put(K,V).put(K,V).build())` --> To `ImmutableMap.of(K,V,K,V)`. ([link](https://github.com/PicnicSupermarket/picnic-platform/pull/8660#discussion_r816604101)).
	- `concatMap(Flux::fromITerable)` -> `concatMapIterable(identity())` ([link](https://github.com/PicnicSupermarket/picnic-pom/pull/1961#discussion_r818794918))
	-
	-
	-
	-
-
- AssertJ rewrites:
	- `isEqualTo(null)` --> `isNull()`
	- `.withMessage(String.format(...))` -> drop `String.format` ([link](https://github.com/PicnicSupermarket/picnic-salesforce-bridge/pull/473#discussion_r816028830))
	-
- ```java
        //      ImmutableRangeMap.Builder<Integer, String> rangeMapStream =
        // ImmutableRangeMap.builder();
  
        //      Stream<Replacement> collect =
        //          matches.stream()
        //              .map(description -> Iterables.getOnlyElement(description.fixes))
        //              .map(fix -> fix.getReplacements(compilationUnit.endPositions))
        //              .map(Iterables::getOnlyElement);
  
        //      Streams.zip(
        //          collect,
        //          matches.stream(),
        //          ((replacement, description) ->
        //              rangeMapStream.put(replacement.range(),
        // getNameFromFQCN(description.checkName))));
        //      ImmutableRangeMap<Integer, String> build = rangeMapStream.build();
        //      //            return rangeMap.build();
  ```
-
- Met Stephan over de extensie:
	- Structuur:
	  ```text
	  1 - error-prone-checks
	    - refaster-support
	     - refaster-resource-compiler
	     - refaster-error-prone-bridge (terrible name)
	     - refaster-test-support
	     - refaster-util (?)
	    - refaster-templates
	      - refaster-assertj-templates
	      - refaster-...-templates
	    
	    
	    - A: Refaster Compiler
	    - B: RefasterCheck
	    - C: "The test framework"
	      - Depends on B.
	    - D: Extra matches/predicate
	    - E: Template Set X
	      - Depends on B.
	      - Depends on C.
	      - Depends on D.
	  ```
	- De `RefasterCheck` moet naar z'n eigen module.
	- Error Prone branch maken met de change die we willen doen. Zorgen dat het daadwerkelijk goed werkt. Als we zeker zijn zou het nice zijn.
-
- Code in verschillende modules zelfde package gebruikt. refaster-executor. errorprone tech errorprone bugpatterns.
- Refastertemplate validaor, niet zelfde package, package uniek per module.
- Validator, refastercheck wordt niet geimporteerd.  Zlefde package,
- executor andere package.
- lets defer; purpose van deze klasse, kleine dummy templates hebt, en dat je die alleen test dat ie die kan vinden bv. Dummy Refaster template, RCT kunnen checken dat ie die vind op classpath. En ook daadwerkelijk toepast. Exception message is zoals je zou verwachten. Coverage deel kan eruit. RefasterCheckTest produceert ook error message. Dat is er bijzonder aan. Je zou simpele test kunnen hebben, datie dingen flagt met clear message. Die template referenced. En dat ie een aanpassing maakt. A dingen van classpath laad, en ook toepast.