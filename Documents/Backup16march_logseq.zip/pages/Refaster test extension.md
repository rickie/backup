- Met Stephan over de extensie:
	- Structuur:
	  ```text
	  1 - error-prone-checks
	    - refaster-support
	     - refaster-resource-compiler
	     - refaster-error-prone-bridge (terrible name)
	     - refaster-test-support
	     - refaster-util (?)
	    - refaster-templates
	      - refaster-assertj-templates
	      - refaster-...-templates
	    
	    
	    - A: Refaster Compiler
	    - B: RefasterCheck
	    - C: "The test framework"
	      - Depends on B.
	    - D: Extra matches/predicate
	    - E: Template Set X
	      - Depends on B.
	      - Depends on C.
	      - Depends on D.
	  ```
	- De `RefasterCheck` moet naar z'n eigen module.
	- Error Prone branch maken met de change die we willen doen. Zorgen dat het daadwerkelijk goed werkt. Als we zeker zijn zou het nice zijn.
-
- Gesprek met Stephan
	- Code in verschillende modules zelfde package gebruikt. refaster-executor. errorprone tech errorprone bugpatterns.
	- Refastertemplate validaor, niet zelfde package, package uniek per module.
	- Validator, refastercheck wordt niet geimporteerd.  Zlefde package,
	- executor andere package.
	- lets to defer?; purpose van deze klasse, kleine dummy templates hebt, en dat je die alleen test dat ie die kan vinden bv. Dummy Refaster template, RCT kunnen checken dat ie die vind op classpath. En ook daadwerkelijk toepast. Exception message is zoals je zou verwachten. Coverage deel kan eruit. RefasterCheckTest produceert ook error message. Dat is er bijzonder aan. Je zou simpele test kunnen hebben, datie dingen flagt met clear message. Die template referenced. En dat ie een aanpassing maakt. A dingen van classpath laad, en ook toepast.
-
- To discuss with Stephan (9 March 2022):
	- Refaster-test-support --> refaster-test-util
	- Refaster-support -> refaster-util
	- RefasterCollectionValidator, good name? RefasterTemplatesTestValidator?
	- Who to ask for a review on this? Only you or?
	- `RefasterCheck` -> RefasterRunner? Should we do something with that name?
	- How to nicely print out the correct things? Go over tests?
	- How do we go from here?
-
- Feedback:
	- ~~refaster-support-test -> refaster.test~~
	- ~~CodeTransformersUtil -> drop Util~~
	- ~~ClassPath import the .RessourceInfo~~
	- ~~package-info met bugchecker is te specifiek~~
	- De list moet exhaustive zijn. 
	  Ticket aanmaken, om JUnit extension te maken die checkt dat je alle tests daadwerkelijk hebt.
	  Die obv classpath kijkt, zijn er "Templates" die in deze module zitten (en evt ook dat die class RefasterTemplates bevat), dan moet die in de specifieke test aanwezig zijn. Die test moet dus alle templates hebben, 1 parameterized test hebben, 1 methode aanroepen (namelijk `validateTemplateCollection`).
	- ~~RefasterTemplateValidator -> TestUtil~~
	- ~~Eigen visitor die deV methodes doorloopt. (NullAway supression kan dan weg)~~
	- ~~addOutputLines bekijken,~~
	- PR aanmaken met voorstel tekst. voor `inputAndOutput` `public` maken.